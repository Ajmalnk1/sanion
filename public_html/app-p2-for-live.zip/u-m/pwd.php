<?php
echo password_hash("sembian", PASSWORD_DEFAULT);