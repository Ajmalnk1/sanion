<?php
echo "<pre>";
$data = $_REQUEST;
print_r($data);
//echo json_encode($data);