<?php
//error_reporting(E_ALL ^ E_NOTICE); 
// // Dev
// $servername = "localhost";
// $username = "root";
// $password = '';
// $dbname = "sanion";

// Prod
$servername = "localhost";
$username = "sanionin_p2";
$password = 'yI3_~vC-)@};';
$dbname = "sanionin_p2";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// email config
$host = 'mail.sanionindia.com';
$mail_username = 'support@sanionindia.com';
$mail_password = '_xo=V2J%mgB{';
$from = 'support@sanionindia.com';
$from_name = 'Sanion';
$bcc_email_to = 'log@sanionindia.com';
$s_template = "";

// Admin
$admin_base_url = "https://www.sanionindia.com//p2/admin/";